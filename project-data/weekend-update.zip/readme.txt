====================================================
Weekend Update: A linework set from Project Linework
====================================================

Linework by Jonah Adkins.

Released to the public domain. Please credit the author and the project wherever possible.

REVISION HISTORY

Version 1.0 — 08/25/2015
-----------------------
Initial release