===================================================
Moriarty Hand: A linework set from Project Linework
===================================================

Linework by Dylan Moriarty.

Released to the public domain. Please credit the author and the project wherever possible.

REVISION HISTORY

Version 1.1 - 09/03/2015
------------------------
NEW: Add small scale version of all files based on new drawings. Old files are now “large scale” version.
ADMIN_0_POLY: Correct “Guinea Bissau” to “Guinea-Bissau”



Version 1.0 — 08/25/2015
-----------------------
Initial release